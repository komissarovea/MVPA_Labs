﻿using System.Windows;

namespace Lab4.GraphicEditor
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
