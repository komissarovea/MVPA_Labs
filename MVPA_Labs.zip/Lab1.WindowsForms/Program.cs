﻿using System.Windows.Forms;

namespace Lab1.WindowsForms
{
    class Program
    {
        static void Main(string[] args)
        {
            Application.Run(new MainForm());
        }
    }
}
